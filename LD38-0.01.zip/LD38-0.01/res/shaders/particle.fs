#version 330

uniform vec3 particleColor;

out vec4 out_color; //the output color of the fragment 

void main(){
	out_color = vec4(1);
}