package tek.game.gameObjects;

import tek.runtime.GameObject;

public class LevelBound extends GameObject{

	@Override
	public void Start() {
		
	}

	@Override
	public void Update(long delta) {
		
	}

}
