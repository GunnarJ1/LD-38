##LD38

All of this is the engine that I'm piecing in preperation for Ludum Dare 38!  
Feel free to reuse this engine for any projects you like. It'd be cool to be credited tho.  
  
If you have questions, ask away on [twitter](http://www.twitter.com/tek256)!